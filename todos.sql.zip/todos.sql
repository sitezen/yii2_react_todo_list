-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Авг 27 2018 г., 15:44
-- Версия сервера: 5.5.25
-- Версия PHP: 5.5.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `todos`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `tags`
--

INSERT INTO `tags` (`id`, `name`) VALUES
(11, 'Del me'),
(6, 'New tag 3'),
(7, 'Other tag 3'),
(4, 'Tag 1'),
(5, 'Tag 11'),
(1, 'Test'),
(8, 'Новый тег'),
(9, 'Тег'),
(2, 'Тег 2'),
(3, 'Тег 22'),
(10, 'ываы');

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `intId` int(11) NOT NULL,
  `taskName` varchar(250) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `priority` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `intId` (`intId`),
  KEY `status` (`status`),
  KEY `priority` (`priority`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `uuid`, `intId`, `taskName`, `status`, `priority`) VALUES
(1, '148d475b-f8ab-a6d4-2c57-7d21422c20e8', 2, 'Задача 2', 0, 1),
(2, 'e664cc0c-0ba8-69d8-7799-5badc55ace22', 1, 'Задача 1', 0, 0),
(3, 'cf7d07d7-9e90-d31e-a5aa-077ce3341181', 3, 'Задача 3', 0, 0),
(5, 'e7d8a64d-7223-b5ea-ca75-b8088b1df12d', 4, 'Задача 5', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tasks_tags`
--

CREATE TABLE IF NOT EXISTS `tasks_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) NOT NULL,
  `tagId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taskId` (`taskId`),
  KEY `tagId` (`tagId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Дамп данных таблицы `tasks_tags`
--

INSERT INTO `tasks_tags` (`id`, `taskId`, `tagId`) VALUES
(8, 5, 9),
(15, 2, 4),
(16, 2, 5),
(19, 3, 6),
(20, 3, 7),
(21, 1, 2),
(22, 1, 3);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `tasks_tags`
--
ALTER TABLE `tasks_tags`
  ADD CONSTRAINT `tasks_tags_ibfk_2` FOREIGN KEY (`tagId`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tasks_tags_ibfk_1` FOREIGN KEY (`taskId`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
